# Aerokube Util Repository
[![Build Status](https://travis-ci.org/aerokube/util.svg?branch=master)](https://travis-ci.org/aerokube/util)

This repository contains source code used in multiple projects.
